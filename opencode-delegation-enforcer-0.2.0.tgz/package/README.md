# opencode-delegation-enforcer

Cost-aware delegation enforcer plugin for [OpenCode](https://opencode.ai).

Tracks model usage, routes Task subagents to cheaper tiers, surfaces cumulative savings inline in chat, and lets you switch brain/medium/cheap model slots via a `trinity` CLI or by typing in the chat window.

## Features

- **Judge pattern** — injects a once-per-session system directive telling the brain model to orchestrate and judge rather than implement; workers (cheap tier) do heavy lifting, brain verifies and synthesises
- **Context compression** — large tool results (>2 000 chars) are written to `~/.claude/scratch/by-hash/` on every turn; results older than the last 5 user+assistant pairs have their in-context body replaced with a pointer, shrinking rolling context and cutting cache_read costs by ~45%
- **Task subagent routing** — when the orchestrator runs on a mid-tier model (e.g. Sonnet), Task subagents are automatically rerouted to the cheap slot (e.g. Haiku/DeepSeek) to maintain a cost gap
- **Write/Edit savings ledger** — tracks every high-tier edit that could have been delegated; shows cumulative estimated savings at the end of each assistant message
- **Context7 nudge** — detects when the model fetches library docs and suggests the context7 MCP as a cheaper alternative
- **Live enable/disable** — toggle the plugin without restarting OpenCode via the `trinity` CLI or the in-chat `trinity` tool
- **Trinity slot switching** — `trinity brain|medium|cheap` switches both OpenCode and Claude Code to the corresponding model in one command

## Install

```bash
npm install -g opencode-delegation-enforcer
```

Then register it in your OpenCode config (`~/.config/opencode/opencode.json`):

```json
{
  "plugin": [
    "opencode-delegation-enforcer"
  ]
}
```

## Configuration

Copy the sample config to `~/.claude/model-tiers.json`:

```bash
cp node_modules/opencode-delegation-enforcer/model-tiers.sample.json ~/.claude/model-tiers.json
```

Edit the slot models to match your providers:

```json
{
  "trinity": {
    "brain":  { "oc": "opencode/claude-sonnet-4-6", "cc": "sonnet" },
    "medium": { "oc": "opencode/claude-haiku-4-5",  "cc": "haiku"  },
    "cheap":  { "oc": "deepseek/deepseek-v4-flash", "cc": "haiku"  }
  }
}
```

`oc` is the OpenCode model ID. `cc` is the Claude Code bare alias (used by the companion hook).

## Optional: trinity CLI

Install the `trinity` CLI for slot switching from the terminal (also used by the companion Claude Code hook):

```bash
# Download
curl -fsSL https://raw.githubusercontent.com/YOUR_REPO/main/trinity > ~/.claude/bin/trinity
chmod +x ~/.claude/bin/trinity
# Add to PATH (add to ~/.zshrc / ~/.bashrc)
export PATH="$HOME/.claude/bin:$PATH"
```

Usage:

```
trinity               # show current state
trinity brain         # switch both runtimes to brain slot
trinity medium        # switch to medium
trinity cheap         # switch to cheap
trinity on            # enable plugin (live, no restart)
trinity off           # disable plugin (live, no restart)
trinity auto          # auto-pick based on credit balance
```

## In-chat control

The plugin registers a `trinity` tool the AI can call when you ask:

- _"switch to medium"_ → calls `trinity { action: "set", slot: "medium" }`
- _"disable the plugin"_ → calls `trinity { action: "disable" }`
- _"trinity status"_ → shows current plugin state inline

Slot changes write to `opencode.json` and take effect on next session restart. Enable/disable is live.

## Companion Claude Code hook

This plugin shares state with a companion bash hook for Claude Code at `~/.claude/hooks/delegation-enforcer.sh`. Both read from `~/.claude/model-tiers.json` and write to `~/.claude/delegation-state.json`.

Install the Claude Code hook: see [`claude-code-delegation-enforcer`](https://github.com/YOUR_REPO).

## Context compression

The plugin's `messages.transform` hook shrinks large tool results out of the rolling context while keeping them safe on disk:

- Any tool result ≥ 2 000 chars is written to `~/.claude/scratch/by-hash/<sha256>.txt` immediately (hot or cold)
- Results that are older than the last 5 conversation pairs (10 messages) have their in-context body replaced with a short pointer: summary + path to the full file
- Hot results keep full content in context; the disk copy is a safety backup only
- Idempotent: the `[ctx-compressed-v1]` marker prevents double-compression

Console output on each transform:
```
[delegation-enforcer] 📦 ctx-compress total saved this transform: ~16 400 tokens
```

## Cost model

Benchmarked against a real 1 216-turn Sonnet session (147M cache_read, 1 070K output tokens, $76.39 baseline):

```
Scenario                                          Cost      vs baseline
A  Pure Opus  (no delegation)                  $ 381.96    +400%
B  Sonnet brain — no optimisations  [BASELINE] $  76.39    —
C  Opus judges + Sonnet workers (50% del)      $ 200.34    +162%
D  Sonnet judges + Haiku workers (50% del)     $  41.23    −46%
E  Pure Haiku (no judgment)                    $  20.37    −73%
F  D + context compression                     $  30.91    −60%
G  B + context compression only                $  55.75    −27%
```

Recommended active strategy: **Scenario F** (Sonnet brain, Haiku workers, context compression on).

## State file

Both the plugin and the Claude Code hook append to `~/.claude/delegation-state.json`:

```json
{
  "lifetime": {
    "warn_count": 42,
    "est_savings_usd": 3.36,
    "missed_context7_usd": 0.12
  },
  "sessions": { ... }
}
```

## License

MIT
