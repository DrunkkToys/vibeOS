// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: 2026 vibeOS <https://github.com/DrunkkToys/vibeOS>
import Fastify from "fastify";
import { initDb } from "./lib/db.js";
import { authMiddleware } from "./middleware/auth.js";
import { usageLoggingMiddleware } from "./middleware/usage-logging.js";
import { delegationRoutes } from "./routes/delegation.js";
import { tierRoutes } from "./routes/tier-routing.js";
import { stressRoutes } from "./routes/stress.js";
import { blackboxRoutes } from "./routes/blackbox.js";
import { tddRoutes } from "./routes/tdd.js";
import { patternRoutes } from "./routes/patterns.js";
import { pricingRoutes } from "./routes/pricing.js";
import { compressionRoutes } from "./routes/compression.js";
import { adminRoutes } from "./routes/admin.js";
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
if (!process.env.VIBEOS_API_MASTER_KEY) {
    console.error("FATAL: VIBEOS_API_MASTER_KEY environment variable is required");
    process.exit(1);
}
const fastify = Fastify({
    logger: { level: process.env.NODE_ENV === "production" ? "info" : "debug" },
    bodyLimit: 10 * 1024 * 1024,
});
fastify.register(async (instance) => {
    authMiddleware(instance);
    usageLoggingMiddleware(instance);
    await delegationRoutes(instance);
    await tierRoutes(instance);
    await stressRoutes(instance);
    await blackboxRoutes(instance);
    await tddRoutes(instance);
    await patternRoutes(instance);
    await pricingRoutes(instance);
    await compressionRoutes(instance);
    await adminRoutes(instance);
    instance.get("/api/v1/health", async () => {
        return { status: "ok", timestamp: new Date().toISOString(), version: "1.0.0" };
    });
});
fastify.get("/health", async () => {
    return { status: "ok", timestamp: new Date().toISOString(), version: "1.0.0" };
});
fastify.get("/favicon.ico", async (request, reply) => {
    reply.code(204).send();
});
fastify.setNotFoundHandler((request, reply) => {
    reply.code(404).send({ error: "not found", code: "NOT_FOUND", path: request.url });
});
fastify.setErrorHandler((error, request, reply) => {
    fastify.log.error(error);
    const statusCode = error.statusCode || error.status || 500;
    const message = statusCode >= 500 ? "Internal server error" : error.message;
    reply.code(statusCode).send({
        error: message,
        code: statusCode >= 500 ? "INTERNAL_ERROR" : "REQUEST_ERROR",
        ...(error.validation && { validation: error.validation }),
    });
});
async function start() {
    initDb();
    console.log("[vibeOS-api] Database initialized");
    const cors = (await import("@fastify/cors")).default;
    await fastify.register(cors, {
        origin: [
            "http://localhost:3000",
            "http://localhost:3333",
            "https://vibetheog.com",
            ...(process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(",").map(s => s.trim()) : [])
        ],
        methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        credentials: true,
        maxAge: 86400,
    });
    try {
        await fastify.listen({ port: PORT, host: HOST });
        console.log("[vibeOS-api] Server running on http://" + HOST + ":" + PORT);
        console.log("[vibeOS-api] Health check: http://" + HOST + ":" + PORT + "/health");
        console.log("[vibeOS-api] Admin endpoints require VIBEOS_API_MASTER_KEY");
    }
    catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
}
start();
export { fastify };
