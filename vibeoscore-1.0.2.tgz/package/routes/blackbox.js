import { appendFileSync, mkdirSync } from "node:fs"
import { dirname, resolve } from "node:path"
import { fileURLToPath } from "node:url"
import { ResolutionTracker, SUB_REGIMES, extractFeatures } from "../lib/blackbox.js"
import { computeControlVector } from "../lib/meta-controller.js"
import { getDb } from "../lib/db.js"
import {
  getBlackboxRoutingModelMeta,
  rebuildBlackboxRoutingModel,
  selectBlackboxMode,
} from "../lib/blackbox-rf.js"

const trackers = new Map()
const __dirname = dirname(fileURLToPath(import.meta.url))
const TELEMETRY_PATH = process.env.VIBEOS_BLACKBOX_TELEMETRY_PATH || resolve(__dirname, "..", "data", "blackbox-telemetry.jsonl")

function readSessionStateRow(sessionId) {
  try {
    const db = getDb()
    return db.prepare("SELECT state_json FROM blackbox_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 1").get(sessionId) || null
  } catch (err) {
    console.error(`[blackbox] readSessionStateRow failed for ${sessionId}: ${err.message}`)
    return null
  }
}

function parseStateJson(row) {
  if (!row?.state_json) return null
  try {
    return JSON.parse(row.state_json)
  } catch (err) {
    return null
  }
}

function loadTrackerFromDb(sessionId) {
  try {
    const data = parseStateJson(readSessionStateRow(sessionId))
    if (data) {
      return ResolutionTracker.deserialize(data)
    }
  } catch (err) {
    console.error(`[blackbox] loadTrackerFromDb failed for ${sessionId}: ${err.message}`)
  }
  return null
}

function appendTelemetryLog(record) {
  try {
    mkdirSync(dirname(TELEMETRY_PATH), { recursive: true })
    appendFileSync(TELEMETRY_PATH, `${JSON.stringify(record)}\n`, "utf-8")
  } catch (err) {
    console.error(`[blackbox] appendTelemetryLog failed: ${err.message}`)
  }
}

function saveTrackerToDb(sessionId, projectId, tracker, telemetry = null) {
  try {
    const db = getDb()
    const existing = parseStateJson(readSessionStateRow(sessionId))
    const serialized = tracker.serialize()
    const mergedTelemetry = {
      ...(existing?.telemetry && typeof existing.telemetry === "object" ? existing.telemetry : {}),
      ...(telemetry && typeof telemetry === "object" ? telemetry : {}),
    }
    const payload = {
      ...(existing && typeof existing === "object" ? existing : {}),
      ...serialized,
    }
    if (Object.keys(mergedTelemetry).length > 0) {
      payload.telemetry = mergedTelemetry
    }
    const stateJson = JSON.stringify(payload)
    const outcome = tracker.getOutcomeHistory().slice(-1)[0]?.outcome || null
    const now = new Date().toISOString()
    db.prepare(`
      INSERT INTO blackbox_sessions (session_id, project_id, state_json, outcome, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id) DO UPDATE SET
        state_json = excluded.state_json,
        project_id = COALESCE(excluded.project_id, blackbox_sessions.project_id),
        outcome = COALESCE(excluded.outcome, blackbox_sessions.outcome),
        updated_at = excluded.updated_at
    `).run(sessionId, projectId || null, stateJson, outcome, now, now)
    if (Object.keys(mergedTelemetry).length > 0) {
      appendTelemetryLog({
        session_id: sessionId,
        project_id: projectId || null,
        event: "session_save",
        created_at: now,
        telemetry: mergedTelemetry,
      })
    }
  } catch (err) {
    console.error(`[blackbox] saveTrackerToDb failed for ${sessionId}: ${err.message}`)
  }
}

function getOrCreateTracker(sessionId, projectId) {
  let tracker = trackers.get(sessionId)
  if (!tracker) {
    tracker = loadTrackerFromDb(sessionId) || new ResolutionTracker(sessionId, projectId)
    trackers.set(sessionId, tracker)
  }
  if (projectId && !tracker.projectId) {
    tracker.projectId = projectId
  }
  return tracker
}

function normalizeRequestedMode(mode) {
  const normalized = String(mode || "").trim().toLowerCase()
  if (normalized === "auto" || normalized === "budget" || normalized === "quality") {
    return normalized
  }
  return null
}

export async function blackboxRoutes(fastify) {
  fastify.post("/api/v1/blackbox/analyze", async (request, reply) => {
    const {
      session_id,
      project_id,
      user_text,
      prompt,
      features,
      action,
      entropy,
      uncertainty,
      embedding,
      latest_stress_multiplier,
      stress_multiplier,
      outcome,
      optimization_mode,
    } = request.body || {}

    if (!user_text && !features && !action) {
      return reply.code(400).send({ error: "user_text is required" })
    }

    const sid = session_id || "default"
    const tracker = getOrCreateTracker(sid, project_id)

    const derivedFeatures = typeof features === "object" && !Array.isArray(features) && Object.keys(features || {}).length > 0
      ? features
      : extractFeatures(user_text)

    const state = tracker.update({
      userText: user_text || "",
      features: derivedFeatures,
      actions: typeof action === "string" ? [action] : (Array.isArray(action) ? action : []),
      entropy: entropy ?? 1.0,
      uncertainty: uncertainty ?? 50,
      embedding: embedding || null,
    })

    const selectionInput = {
      session_id: sid,
      project_id: project_id || tracker.projectId || null,
      user_text: user_text || "",
      prompt: prompt || "",
      features: derivedFeatures,
      state,
      pivot_detected: state.pivot_detected,
      pivot_score: state.pivot_score,
      resolution: state.resolution,
      continuity_state: state.continuity_state,
      is_looping: state.is_looping,
      loop_count: state.loop_consecutive,
      loop_consecutive: state.loop_consecutive,
      loop_intervention_level: state.loop_intervention_level,
      outcome: outcome || state.outcome || null,
      signals: state.signals,
      stress_multiplier: latest_stress_multiplier ?? stress_multiplier ?? 0,
      latest_stress_multiplier: latest_stress_multiplier ?? stress_multiplier ?? 0,
    }
    const requestedMode = normalizeRequestedMode(optimization_mode)
    const selected = requestedMode && requestedMode !== "auto"
      ? {
          mode: requestedMode,
          source: "manual",
          confidence: 1,
          probabilities: { [requestedMode]: 1 },
          features: selectionInput.features,
        }
      : selectBlackboxMode(selectionInput)
    const controlVector = computeControlVector({
      ...state,
      user_text: user_text || "",
      prompt: prompt || "",
      features: derivedFeatures,
      latest_stress_multiplier: latest_stress_multiplier ?? stress_multiplier ?? 0,
    }, action, selected.mode)
    const telemetry = {
      observed_at: new Date().toISOString(),
      input: {
        user_text: user_text || "",
        prompt: prompt || "",
        action: typeof action === "string" ? action : Array.isArray(action) ? action[0] || null : null,
        entropy: entropy ?? 1.0,
        uncertainty: uncertainty ?? 50,
        latest_stress_multiplier: latest_stress_multiplier ?? stress_multiplier ?? 0,
        optimization_mode: requestedMode || "auto",
      },
      selection: {
        optimization_mode: selected.mode,
        requested_mode: requestedMode || "auto",
        source: selected.source,
        confidence: selected.confidence,
        probabilities: selected.probabilities || {},
      },
      context_packet: controlVector.context_packet,
      control_vector: controlVector,
      signals: {
        sub_regime: state.sub_regime,
        resolution: state.resolution,
        continuity_state: state.continuity_state,
        pivot_detected: state.pivot_detected,
        pivot_score: state.pivot_score,
        is_looping: state.is_looping,
        loop_intervention_level: state.loop_intervention_level,
        loop_consecutive: state.loop_consecutive,
        action_consistency: state.signals?.action_consistency,
        n_interactions: state.n_interactions,
        outcome: outcome || state.outcome || null,
      },
      features: derivedFeatures,
      feature_vector: selected.features || [],
    }

    tracker.annotateLastTurn(telemetry)
    saveTrackerToDb(sid, project_id, tracker, telemetry)

    return {
      ...state,
      session_id: sid,
      project_id: project_id || tracker.projectId || null,
      features: derivedFeatures,
      optimization_mode: selected.mode,
      requested_mode: requestedMode || "auto",
      optimization_source: selected.source,
      optimization_confidence: selected.confidence,
      context_packet: controlVector.context_packet,
      control_vector: controlVector,
    }
  })

  fastify.post("/api/v1/blackbox/state", async (request, reply) => {
    const { session_id, project_id } = request.body || {}
    const sid = session_id || "default"
    const tracker = getOrCreateTracker(sid, project_id)

    return {
      ...tracker.getState(),
      session_id: sid,
      project_id: project_id || tracker.projectId || null,
    }
  })

  fastify.post("/api/v1/blackbox/reset", async (request, reply) => {
    const { session_id } = request.body || {}
    const sid = session_id || "default"
    trackers.delete(sid)
    try {
      getDb().prepare("DELETE FROM blackbox_sessions WHERE session_id = ?").run(sid)
    } catch {}
    return { ok: true, message: "tracker reset" }
  })

  fastify.get("/api/v1/blackbox/regimes", async (request, reply) => {
    return { regimes: SUB_REGIMES }
  })

  fastify.get("/api/v1/blackbox/project-sessions", async (request, reply) => {
    const { project_id } = request.query || {}
    if (!project_id) {
      return reply.code(400).send({ error: "project_id query parameter is required" })
    }
    try {
      const db = getDb()
      const rows = db.prepare(
        "SELECT session_id, created_at, updated_at, outcome FROM blackbox_sessions WHERE project_id = ? ORDER BY updated_at DESC LIMIT 50"
      ).all(project_id)
      return { project_id, sessions: rows }
    } catch (err) {
      return reply.code(500).send({ error: "failed to query sessions" })
    }
  })

  fastify.post("/api/v1/blackbox/outcome", async (request, reply) => {
    const { session_id, outcome } = request.body || {}
    if (!session_id || !outcome) {
      return reply.code(400).send({ error: "session_id and outcome are required" })
    }
    const sid = session_id
    const tracker = trackers.get(sid) || loadTrackerFromDb(sid)
    if (tracker) {
      tracker.recordOutcome(outcome)
      tracker.annotateLastTurn({
        observed_at: new Date().toISOString(),
        outcome,
      })
    }
    try {
      const db = getDb()
      db.prepare("UPDATE blackbox_sessions SET outcome = ?, updated_at = ? WHERE session_id = ?")
        .run(outcome, new Date().toISOString(), sid)
      if (tracker) {
        saveTrackerToDb(sid, tracker.projectId || null, tracker, {
          observed_at: new Date().toISOString(),
          outcome,
        })
      }
    } catch {}
    return { ok: true, session_id: sid, outcome }
  })

  fastify.post("/api/v1/blackbox/calibrate", async (request, reply) => {
    const { project_id } = request.body || {}
    const pid = project_id || "global"
    try {
      const db = getDb()
      const sessions = db.prepare(
        "SELECT state_json, outcome FROM blackbox_sessions WHERE project_id = ? AND outcome IS NOT NULL"
      ).all(pid)

      if (sessions.length < 3) {
        return reply.code(400).send({
          error: "need at least 3 sessions with outcomes to calibrate",
          samples: sessions.length,
        })
      }

      const outcomes = sessions.map(s => JSON.parse(s.state_json))
      const loopSessions = outcomes.filter(o => {
        try {
          const state = typeof o === "string" ? JSON.parse(o) : o
          return state?.is_looping
        } catch { return false }
      })
      const positiveOutcomes = sessions.filter(s => s.outcome === "positive").length
      const total = sessions.length

      const weights = {
        momentum: [-0.3, 0.5, 0.2],
        subRegime: {
          CONVERGING: -0.10,
          CLOSED: -0.10,
          DIVERGENT: +0.15,
          REFINING: 0.00,
          EXPLORING: +0.10,
          LOOPING: +0.15,
          INIT: +0.05,
        },
        loopJaccard: loopSessions.length > 0 ? 0.6 - (loopSessions.length / total) * 0.1 : 0.6,
        closureConfidence: positiveOutcomes > 0 ? 0.7 - (positiveOutcomes / total) * 0.1 : 0.7,
      }

      db.prepare(`
        INSERT INTO blackbox_calibration (project_id, weights_json, samples_used, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(project_id) DO UPDATE SET
          weights_json = excluded.weights_json,
          samples_used = excluded.samples_used,
          updated_at = excluded.updated_at
      `).run(pid, JSON.stringify(weights), total, new Date().toISOString())

      const tracker = [...trackers.values()].find(t => t.projectId === pid)
      if (tracker) {
        tracker.setCalibratedWeights(weights)
      }

      return { ok: true, project_id: pid, samples: total, weights }
    } catch (err) {
      return reply.code(500).send({ error: `calibration failed: ${err.message}` })
    }
  })

  fastify.get("/api/v1/blackbox/calibration", async (request, reply) => {
    const { project_id } = request.query || {}
    const pid = project_id || "global"
    try {
      const db = getDb()
      const row = db.prepare(
        "SELECT weights_json, samples_used, updated_at FROM blackbox_calibration WHERE project_id = ?"
      ).get(pid)
      if (!row) {
        return { project_id: pid, calibrated: false, message: "no calibration data yet" }
      }
      return {
        project_id: pid,
        calibrated: true,
        weights: JSON.parse(row.weights_json),
        samples_used: row.samples_used,
        updated_at: row.updated_at,
      }
    } catch (err) {
      return reply.code(500).send({ error: `failed to read calibration: ${err.message}` })
    }
  })

  fastify.post("/api/v1/blackbox/control-vector", async (request, reply) => {
    const {
      sub_regime,
      is_looping,
      loop_intervention_level,
      momentum,
      n_interactions,
      latest_stress_multiplier,
      action,
      optimization_mode,
      user_text,
      prompt,
      features,
      pivot_detected,
      pivot_score,
      resolution,
      continuity_state,
      outcome,
      signals,
    } = request.body || {}
    const state = {
      sub_regime,
      is_looping,
      loop_intervention_level,
      momentum,
      n_interactions,
      latest_stress_multiplier,
      user_text,
      prompt,
      features,
      pivot_detected,
      pivot_score,
      resolution,
      continuity_state,
      outcome,
      signals,
    }
    const cv = computeControlVector(state, action, optimization_mode)
    return { ok: true, control_vector: cv }
  })

  fastify.post("/api/v1/blackbox/select-mode", async (request, reply) => {
    const result = selectBlackboxMode(request.body || {})
    return { ok: true, mode: result.mode, ...result }
  })

  fastify.get("/api/v1/blackbox/model", async () => {
    return { ok: true, ...getBlackboxRoutingModelMeta() }
  })

  fastify.post("/api/v1/blackbox/model/rebuild", async (request, reply) => {
    const {
      project_id,
      limit,
      include_bootstrap,
      seed,
      tree_count,
      max_depth,
      min_samples_split,
      min_samples_leaf,
      feature_subsample,
      confidence_threshold,
    } = request.body || {}

    const result = rebuildBlackboxRoutingModel({
      projectId: project_id || null,
      limit: Number.isFinite(Number(limit)) ? Number(limit) : 5000,
      includeBootstrap: include_bootstrap !== false,
      seed: Number.isFinite(Number(seed)) ? Number(seed) : 42,
      treeCount: Number.isFinite(Number(tree_count)) ? Number(tree_count) : undefined,
      maxDepth: Number.isFinite(Number(max_depth)) ? Number(max_depth) : undefined,
      minSamplesSplit: Number.isFinite(Number(min_samples_split)) ? Number(min_samples_split) : undefined,
      minSamplesLeaf: Number.isFinite(Number(min_samples_leaf)) ? Number(min_samples_leaf) : undefined,
      featureSubsample: Number.isFinite(Number(feature_subsample)) ? Number(feature_subsample) : undefined,
      confidenceThreshold: Number.isFinite(Number(confidence_threshold)) ? Number(confidence_threshold) : undefined,
    })

    if (!result.ok) {
      return reply.code(400).send(result)
    }
    return result
  })
}
