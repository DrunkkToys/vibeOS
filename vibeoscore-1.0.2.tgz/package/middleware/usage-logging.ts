import { getDb } from "../lib/db.js"

export function usageLoggingMiddleware(fastify: any) {
  fastify.addHook("onResponse", async (request: any, reply: any) => {
    const urlPath = request.url.split("?")[0]
    if (!urlPath.startsWith("/api/v1/") && !urlPath.startsWith("/admin/")) return

    try {
      const db = getDb()
      const duration = request.hrtime ? Math.round(request.hrtime()[1] / 1e6) : 0
      const requestBody = request.body ? JSON.stringify(request.body).substring(0, 4096) : null
      const responseSize = reply.getHeader("content-length") || 0
      if (request.tokenId) {
        db.prepare([
          "INSERT INTO usage_log (token_id, endpoint, request_body, response_size, latency_ms)",
          "VALUES (?, ?, ?, ?, ?)"
        ].join(" ")).run(
          request.tokenId,
          urlPath,
          requestBody,
          responseSize,
          duration
        )
      } else if (request.adminAuth) {
        db.prepare([
          "INSERT INTO admin_audit_log (method, endpoint, request_body, response_status, response_size, latency_ms)",
          "VALUES (?, ?, ?, ?, ?, ?)"
        ].join(" ")).run(
          request.method,
          urlPath,
          requestBody,
          reply.statusCode,
          responseSize,
          duration
        )
      }
    } catch (err: any) {
      console.error("[vibeOS-api] usage logging error: " + err.message)
    }
  })
}
