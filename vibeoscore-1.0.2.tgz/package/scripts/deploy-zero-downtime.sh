#!/bin/bash
set -euo pipefail

VPS_HOST="${VPS_HOST:-45.132.242.217}"
VPS_USER="${VPS_USER:-root}"
BASE="/var/www/vibeos-api"
REL="$BASE/releases/$(date +%s)"
CUR="$BASE/current"
P1=3000
P2=3001
NGX="/etc/nginx/sites-enabled/vibeos-api.conf"

log() { echo "  [$1] $2"; }
r() { ssh "$VPS_USER@$VPS_HOST" "$@"; }
pid() { r "lsof -ti :$1 2>/dev/null || true"; }
up() { r "curl -sf -o /dev/null http://127.0.0.1:$1/health" 2>/dev/null; return $?; }

echo "[vibeOS-api] Zero-downtime deploy"

# 1. Upload
log "deploy" "Creating release dir..."
r "mkdir -p $REL/data"

log "deploy" "Uploading files..."
D="$(dirname "$0")/.."
for f in server.js start.sh lib routes middleware package.json; do
  [ -e "$D/$f" ] && scp -qr "$D/$f" "$VPS_USER@$VPS_HOST:$REL/"
done

log "deps" "npm install..."
r "cd $REL && npm install --omit=dev --silent 2>/dev/null"

# 2. .env
log "env" "Copying .env..."
r "cp $BASE/.env $REL/.env 2>/dev/null || cp $CUR/.env $REL/.env 2>/dev/null ||:"

# 3. Blue-green port detection
CUR_P=""; NEW_P=""
up $P1 && CUR_P=$P1 && NEW_P=$P2 || true
up $P2 && CUR_P=$P2 && NEW_P=$P1 || true
[ -z "$CUR_P" ] && NEW_P=$P1 && log "deploy" "Fresh start on $NEW_P" || log "deploy" "Instance on $CUR_P, deploying to $NEW_P"

# 4. Start new instance (detached via ssh -f)
log "start" "Starting on port $NEW_P..."
r "cd $REL && screen -dmS vibeos-$NEW_P env PORT=$NEW_P bash start.sh"
sleep 3

# 5. Health check
log "health" "Waiting for port $NEW_P..."
for i in $(seq 1 15); do
  up $NEW_P && log "health" "OK after ${i}s" && break || true
  [ $i -eq 15 ] && log "health" "FAIL" && r "screen -S vibeos-$NEW_P -X quit 2>/dev/null; true" && exit 1
  sleep 1
done

# 6. Swap nginx
log "nginx" "Switching to port $NEW_P..."
r "sed -i 's|proxy_pass http://127.0.0.1:[0-9]*|proxy_pass http://127.0.0.1:$NEW_P|g' $NGX"
r "nginx -t && systemctl reload nginx"

# 7. Kill old
if [ -n "$CUR_P" ]; then
  O=$(pid $CUR_P)
  [ -n "$O" ] && log "stop" "Stopping old PID $O" && r "kill $O 2>/dev/null; sleep 2; kill -9 $O 2>/dev/null; true"
fi

# 8. Symlink + systemd
log "symlink" "$CUR -> $REL"
r "ln -sfn $REL $CUR && cp $REL/start.sh $BASE/start.sh"
r "sed -i 's|WorkingDirectory=.*|WorkingDirectory=$CUR|' /etc/systemd/system/vibeos-api.service 2>/dev/null; systemctl daemon-reload 2>/dev/null; true"

# 9. Cleanup
log "cleanup" "Keeping last 3 releases..."
r "ls -1d $BASE/releases/*/ 2>/dev/null | sort -r | tail -n +4 | xargs rm -rf 2>/dev/null; true"

echo
echo "[vibeOS-api] Done! Port $NEW_P | https://api.vibetheog.com/health"
