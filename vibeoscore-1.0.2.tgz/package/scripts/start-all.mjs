#!/usr/bin/env node
import { spawn } from "node:child_process"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = dirname(__dirname)

const server = spawn(process.execPath, [join(ROOT, "server.js")], {
  cwd: ROOT,
  env: { ...process.env, PORT: process.env.VIBEOS_API_PORT || process.env.PORT || "3000" },
  stdio: "inherit",
})

const dashboard = spawn(process.execPath, [join(ROOT, "scripts", "dashboard-server.mjs")], {
  cwd: ROOT,
  env: {
    ...process.env,
    PORT: process.env.VIBEOS_DASHBOARD_PORT || "3333",
    VIBEOS_BACKEND_HEALTH_URL: process.env.VIBEOS_BACKEND_HEALTH_URL || "http://127.0.0.1:3000/health",
  },
  stdio: "inherit",
})

function shutdown(code = 0) {
  try { server.kill("SIGTERM") } catch {}
  try { dashboard.kill("SIGTERM") } catch {}
  process.exit(code)
}

server.on("exit", (code) => shutdown(code ?? 0))
dashboard.on("exit", (code) => shutdown(code ?? 0))
process.on("SIGINT", () => shutdown(0))
process.on("SIGTERM", () => shutdown(0))
