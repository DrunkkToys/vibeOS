# vibeOScore

## Tech Stack

`typescript`, `javascript`

## Features

(Feature list maintained by vibeOS — run `trinity guard` to refresh)

## Getting Started

```bash
# Clone and install dependencies
```

## API Token (Alpha)

This is the vibeOScore API token. It can be revoked and will be replaced with auto-generated tokens in a future release.

```
VIBEOS_API_TOKEN=vos_59d73aa4b7838a7ca9dafe957993177b5629c7954091db3350b4150882ff7064
```

Set this as an environment variable or add it to `~/.claude/.env.production`:

```bash
export VIBEOS_API_TOKEN=vos_59d73aa4b7838a7ca9dafe957993177b5629c7954091db3350b4150882ff7064
```
